'use client'

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { ArrowRight, Sparkles } from 'lucide-react'

export function Hero() {
  return (
    <section className="relative overflow-hidden min-h-[90vh] flex items-center">
      {/* Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#F0EEE9] via-[#F0EEE9]/95 to-[#D4AF37]/10" />
      
      {/* Subtle animated particles */}
      <div className="absolute inset-0">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-[1px] h-[1px] bg-[#D4AF37] rounded-full"
            initial={{
              x: Math.random() * 100 + '%',
              y: Math.random() * 100 + '%',
              opacity: 0.3,
            }}
            animate={{
              y: [null, '-100px'],
              opacity: [0.3, 0, 0.3],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="container relative mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 mb-6 px-4 py-2 bg-[#D4AF37]/10 rounded-full">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-sm tracking-widest uppercase text-[#1A1A1A]">
                Luxury Redefined
              </span>
            </div>

            <h1 className="font-instrument-serif text-5xl sm:text-6xl md:text-7xl lg:text-8xl italic mb-6 text-[#1A1A1A]">
              Beauty <span className="not-italic">that</span>{' '}
              <span className="text-[#D4AF37]">fits</span>{' '}
              <span className="not-italic">you</span>
            </h1>

            <p className="text-lg sm:text-xl text-[#1A1A1A]/70 mb-10 max-w-2xl mx-auto">
              Experience personalized luxury beauty services in our tranquil oasis.
              Our AI-powered analysis ensures every treatment complements your unique features.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="group tracking-widest"
              >
                <Link href="/book">
                  Book Your Session
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="tracking-widest"
              >
                <Link href="/services">
                  Explore Services
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Stats bar */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-20 glass rounded-2xl p-6 max-w-4xl mx-auto"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { value: '5000+', label: 'Satisfied Clients' },
              { value: '98%', label: 'Client Retention' },
              { value: '15', label: 'Expert Stylists' },
              { value: '45min', label: 'Avg. Wait Time' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="font-instrument-serif text-3xl italic text-[#D4AF37] mb-1">
                  {stat.value}
                </div>
                <div className="text-sm tracking-widest uppercase text-[#1A1A1A]/60">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}