import type { Metadata } from 'next'
import { Navigation } from '@/components/features/navigation'
import { Footer } from '@/components/features/footer'

export const metadata: Metadata = {
  title: 'Aura-Luxe Salon | Luxury Beauty Services',
  description: 'Experience premium beauty services in a tranquil, luxurious environment.',
}

export default function MarketingLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <main className="flex-1">
        {children}
      </main>
      <Footer />
    </div>
  )
}