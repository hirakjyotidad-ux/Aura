'use client'

import { useBooking } from '@/components/providers/booking-provider'
import { motion } from 'framer-motion'
import { Check } from 'lucide-react'

const steps = [
  { id: 'service', label: 'Service', description: 'Choose treatment' },
  { id: 'date', label: 'Date', description: 'Select day' },
  { id: 'time', label: 'Time', description: 'Pick slot' },
  { id: 'details', label: 'Details', description: 'Your info' },
  { id: 'confirm', label: 'Confirm', description: 'Review & book' },
]

export function BookingStepper() {
  const { currentStep } = useBooking()

  return (
    <nav aria-label="Booking progress">
      <ol className="flex items-center justify-center">
        {steps.map((step, index) => {
          const stepIndex = steps.findIndex(s => s.id === currentStep)
          const isActive = step.id === currentStep
          const isCompleted = steps.findIndex(s => s.id === step.id) < stepIndex
          const isLast = index === steps.length - 1

          return (
            <li key={step.id} className="flex items-center">
              <div className="relative flex flex-col items-center">
                {/* Connection line */}
                {!isLast && (
                  <div className="absolute top-4 left-1/2 w-full h-[2px] -z-10">
                    <div className="h-full bg-[#1A1A1A]/10" />
                    {isCompleted && (
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: '100%' }}
                        className="absolute inset-0 h-full bg-[#D4AF37]"
                      />
                    )}
                  </div>
                )}

                {/* Step circle */}
                <div className={cn(
                  'w-8 h-8 rounded-full flex items-center justify-center border-2 transition-colors',
                  isActive && 'border-[#D4AF37] bg-[#D4AF37]',
                  isCompleted && 'border-[#D4AF37] bg-[#D4AF37]',
                  !isActive && !isCompleted && 'border-[#1A1A1A]/20'
                )}>
                  {isCompleted ? (
                    <Check className="w-4 h-4 text-[#1A1A1A]" />
                  ) : (
                    <span className={cn(
                      'text-sm font-medium',
                      isActive ? 'text-[#1A1A1A]' : 'text-[#1A1A1A]/40'
                    )}>
                      {index + 1}
                    </span>
                  )}
                </div>

                {/* Step label */}
                <div className="mt-2 text-center">
                  <div className={cn(
                    'text-xs tracking-widest uppercase',
                    isActive || isCompleted
                      ? 'text-[#1A1A1A] font-medium'
                      : 'text-[#1A1A1A]/40'
                  )}>
                    {step.label}
                  </div>
                  <div className="text-xs text-[#1A1A1A]/60 mt-1">
                    {step.description}
                  </div>
                </div>
              </div>
            </li>
          )
        })}
      </ol>
    </nav>
  )
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ')
}