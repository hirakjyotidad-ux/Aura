import type { Metadata } from 'next'
import { BookingProvider } from '@/components/providers/booking-provider'
import { BookingStepper } from '@/components/features/booking-stepper'

export const metadata: Metadata = {
  title: 'Book Your Appointment | Aura-Luxe Salon',
  description: 'Schedule your luxury beauty service with our expert stylists.',
}

export default function BookingLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <BookingProvider>
      <div className="min-h-screen bg-[#F0EEE9] pt-16">
        <div className="container mx-auto px-4 py-8">
          <BookingStepper />
          <div className="mt-8">
            {children}
          </div>
        </div>
      </div>
    </BookingProvider>
  )
}