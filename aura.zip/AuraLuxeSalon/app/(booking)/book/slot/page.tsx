'use client'

import { useState, useEffect, useCallback } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { useBooking } from '@/components/providers/booking-provider'
import { ArrowLeft, ArrowRight, Clock, Loader2 } from 'lucide-react'
import { formatDate, formatTime } from '@/lib/utils'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'

interface AvailableSlot {
  start_time: string
  end_time: string
  available_count: number
}

export default function SlotSelectionPage() {
  const router = useRouter()
  const { bookingData, setBookingData } = useBooking()
  const [availableSlots, setAvailableSlots] = useState<AvailableSlot[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)
  const [isBooking, setIsBooking] = useState(false)

  const fetchAvailableSlots = useCallback(async () => {
    if (!bookingData.date || !bookingData.serviceId) {
      router.push('/book')
      return
    }

    try {
      setLoading(true)
      
      const { data, error } = await supabase
        .rpc('get_available_slots', {
          p_date: bookingData.date,
          p_service_id: bookingData.serviceId
        })

      if (error) throw error
      setAvailableSlots(data || [])
    } catch (error) {
      console.error('Error fetching slots:', error)
      toast.error('Failed to load available slots')
    } finally {
      setLoading(false)
    }
  }, [bookingData.date, bookingData.serviceId, router])

  useEffect(() => {
    fetchAvailableSlots()
  }, [fetchAvailableSlots])

  const handleSlotSelect = (slotStart: string) => {
    setSelectedSlot(slotStart)
  }

  const handleBookSlot = async () => {
    if (!selectedSlot || !bookingData.date || !bookingData.serviceId) {
      toast.error('Please select a time slot')
      return
    }

    setIsBooking(true)

    try {
      // Calculate end time based on service duration
      const selectedSlotData = availableSlots.find(s => s.start_time === selectedSlot)
      if (!selectedSlotData) throw new Error('Slot not found')

      setBookingData({
        slotStart: selectedSlot,
        slotEnd: selectedSlotData.end_time,
      })

      router.push('/book/confirmation')
    } catch (error) {
      console.error('Error booking slot:', error)
      toast.error('Failed to book slot. Please try again.')
    } finally {
      setIsBooking(false)
    }
  }

  const handleGoBack = () => {
    router.push('/book/date')
  }

  if (!bookingData.date || !bookingData.serviceId) {
    router.push('/book')
    return null
  }

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <button
          onClick={handleGoBack}
          className="flex items-center gap-2 text-[#1A1A1A]/70 hover:text-[#D4AF37] transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to date selection
        </button>

        <h1 className="font-instrument-serif text-4xl md:text-5xl italic mb-4 text-[#1A1A1A]">
          Select Your <span className="text-[#D4AF37]">Time</span>
        </h1>
        <div className="flex items-center gap-4 text-lg text-[#1A1A1A]/70">
          <span>{bookingData.serviceName}</span>
          <span>•</span>
          <span>{formatDate(bookingData.date)}</span>
        </div>
      </motion.div>

      {/* Available Slots Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass rounded-2xl p-6 mb-8"
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-instrument-serif text-xl italic mb-1 text-[#1A1A1A]">
              Available Time Slots
            </h3>
            <p className="text-[#1A1A1A]/70">
              Select your preferred appointment time
            </p>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 bg-[#D4AF37]/30 rounded-sm" />
            <span className="text-[#1A1A1A]/60">Limited availability</span>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 text-[#D4AF37] animate-spin" />
          </div>
        ) : availableSlots.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-[#1A1A1A]/70 mb-4">No available slots for this date</p>
            <Button
              variant="outline"
              onClick={handleGoBack}
              className="tracking-widest"
            >
              Choose Another Date
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {availableSlots.map((slot) => {
              const isAvailable = slot.available_count > 0
              const isSelected = selectedSlot === slot.start_time
              const isLimited = slot.available_count === 1

              return (
                <button
                  key={slot.start_time}
                  onClick={() => isAvailable && handleSlotSelect(slot.start_time)}
                  disabled={!isAvailable}
                  className={cn(
                    'glass rounded-xl p-4 text-center transition-all',
                    isSelected && 'ring-2 ring-[#D4AF37] ring-offset-2 ring-offset-[#F0EEE9]',
                    isAvailable
                      ? 'hover:shadow-lg cursor-pointer'
                      : 'opacity-50 cursor-not-allowed'
                  )}
                >
                  <div className="text-lg font-semibold mb-1">
                    {formatTime(slot.start_time)}
                  </div>
                  <div className="text-sm text-[#1A1A1A]/60 mb-2">
                    to {formatTime(slot.end_time)}
                  </div>
                  <div className={cn(
                    'text-xs tracking-widest uppercase px-2 py-1 rounded',
                    isLimited
                      ? 'bg-[#D4AF37]/10 text-[#D4AF37]'
                      : isAvailable
                      ? 'bg-[#F0EEE9]/50 text-[#1A1A1A]/60'
                      : 'bg-[#A71F13]/10 text-[#A71F13]'
                  )}>
                    {isAvailable
                      ? `${slot.available_count} left`
                      : 'Full'}
                  </div>
                </button>
              )
            })}
          </div>
        )}
      </motion.div>

      {/* Selected Slot Summary */}
      {selectedSlot && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-2xl p-6 mb-8"
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-instrument-serif text-xl italic mb-2 text-[#1A1A1A]">
                Selected Appointment
              </h3>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-[#D4AF37]" />
                  <span className="text-[#1A1A1A]">
                    {formatTime(selectedSlot)} -{' '}
                    {formatTime(
                      availableSlots.find(s => s.start_time === selectedSlot)?.end_time || ''
                    )}
                  </span>
                </div>
                <div className="text-[#1A1A1A]/70">
                  {formatDate(bookingData.date)}
                </div>
              </div>
            </div>
            <Button
              onClick={handleBookSlot}
              disabled={isBooking}
              size="lg"
              className="tracking-widest group"
            >
              {isBooking ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Booking...
                </>
              ) : (
                <>
                  Continue to Details
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </>
              )}
            </Button>
          </div>
        </motion.div>
      )}

      {/* Timezone Notice */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="text-center text-sm text-[#1A1A1A]/50"
      >
        <p>All times are in your local timezone. Appointment duration: {bookingData.serviceDuration} minutes</p>
      </motion.div>
    </div>
  )
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ')
}