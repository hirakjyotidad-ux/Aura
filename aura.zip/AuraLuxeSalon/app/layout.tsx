import type { Metadata } from 'next'
import { Instrument_Serif, Manrope, Geist_Sans } from 'next/font/google'
import './globals.css'
import { Toaster } from '@/components/ui/toaster'
import { ThemeProvider } from '@/components/theme-provider'

const instrumentSerif = Instrument_Serif({
  weight: '400',
  subsets: ['latin'],
  variable: '--font-instrument-serif',
  style: ['italic', 'normal']
})

const manrope = Manrope({
  subsets: ['latin'],
  variable: '--font-manrope',
})

const geistSans = Geist_Sans({
  subsets: ['latin'],
  variable: '--font-geist-sans',
})

export const metadata: Metadata = {
  title: 'Aura-Luxe Salon | Premium Beauty Experiences',
  description: 'Experience luxury beauty services tailored to your unique features. Book appointments with our expert stylists.',
  keywords: ['salon', 'beauty', 'booking', 'luxury', 'hair', 'skin', 'nails'],
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://aura-luxe.com',
    title: 'Aura-Luxe Salon',
    description: 'Premium Beauty Experiences',
    siteName: 'Aura-Luxe Salon',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html 
      lang="en" 
      className={`${instrumentSerif.variable} ${manrope.variable} ${geistSans.variable}`}
      suppressHydrationWarning
    >
      <body className={`${manrope.className} bg-[#F0EEE9] text-[#1A1A1A] min-h-screen`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}