export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      services: {
        Row: {
          id: string
          name: string
          description: string | null
          price: number
          duration_minutes: number
          category: 'hair' | 'skin' | 'nails' | 'makeup'
          image_url: string | null
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          price: number
          duration_minutes: number
          category: 'hair' | 'skin' | 'nails' | 'makeup'
          image_url?: string | null
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          price?: number
          duration_minutes?: number
          category?: 'hair' | 'skin' | 'nails' | 'makeup'
          image_url?: string | null
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      bookings: {
        Row: {
          id: string
          user_id: string | null
          service_id: string
          customer_name: string
          customer_email: string
          customer_phone: string | null
          booking_date: string
          start_time: string
          end_time: string
          status: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'no-show'
          notes: string | null
          face_shape: string | null
          recommended_service_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id?: string | null
          service_id: string
          customer_name: string
          customer_email: string
          customer_phone?: string | null
          booking_date: string
          start_time: string
          end_time: string
          status?: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'no-show'
          notes?: string | null
          face_shape?: string | null
          recommended_service_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string | null
          service_id?: string
          customer_name?: string
          customer_email?: string
          customer_phone?: string | null
          booking_date?: string
          start_time?: string
          end_time?: string
          status?: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'no-show'
          notes?: string | null
          face_shape?: string | null
          recommended_service_id?: string | null
          created_at?: string
          updated_at?: string
        }
      }
    }
    Functions: {
      get_available_slots: {
        Args: {
          p_date: string
          p_service_id: string
        }
        Returns: {
          start_time: string
          end_time: string
          available_count: number
        }[]
      }
      check_booking_capacity: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
    }
  }
}