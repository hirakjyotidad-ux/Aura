'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Camera, RefreshCw, Sparkles, X, Check } from 'lucide-react'
import { toast } from 'sonner'
import * as faceapi from 'face-api.js'
import { cn } from '@/lib/utils'

// Client-side only face shape detection
const FACE_SHAPE_THRESHOLDS = {
  OVAL: { ratio: { min: 1.3, max: 1.6 } },
  ROUND: { ratio: { min: 1.0, max: 1.3 } },
  SQUARE: { ratio: { min: 1.0, max: 1.3 }, jawline: 'angular' },
  HEART: { ratio: { min: 1.3, max: 1.6 }, forehead: 'wide', chin: 'pointed' },
  DIAMOND: { ratio: { min: 1.6, max: 1.9 }, cheekbones: 'wide' },
}

interface FaceAnalysisResult {
  faceShape: string
  confidence: number
  recommendations: string[]
  measurements: {
    faceWidth: number
    faceLength: number
    ratio: number
  }
}

export function FaceAnalyzer() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [hasCameraAccess, setHasCameraAccess] = useState(false)
  const [modelsLoaded, setModelsLoaded] = useState(false)
  const [result, setResult] = useState<FaceAnalysisResult | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)

  // Load face-api.js models
  useEffect(() => {
    async function loadModels() {
      try {
        await Promise.all([
          faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
          faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
          faceapi.nets.faceRecognitionNet.loadFromUri('/models'),
        ])
        setModelsLoaded(true)
      } catch (error) {
        console.error('Failed to load face detection models:', error)
        toast.error('Face analysis features are temporarily unavailable')
      }
    }

    loadModels()
  }, [])

  // Initialize camera
  const initializeCamera = useCallback(async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera API not supported')
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user',
        },
        audio: false,
      })

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setHasCameraAccess(true)
      }
    } catch (error) {
      console.error('Camera access error:', error)
      toast.error('Camera access denied. Please allow camera permissions.')
      setHasCameraAccess(false)
    }
  }, [])

  // Start camera on mount
  useEffect(() => {
    if (modelsLoaded) {
      initializeCamera()
    }

    return () => {
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream
        stream.getTracks().forEach(track => track.stop())
      }
    }
  }, [modelsLoaded, initializeCamera])

  // Analyze face from video frame
  const analyzeFace = useCallback(async () => {
    if (!videoRef.current || !canvasRef.current || !modelsLoaded) {
      toast.error('Face analyzer not ready')
      return
    }

    setIsProcessing(true)
    setIsAnalyzing(true)

    try {
      const video = videoRef.current
      const canvas = canvasRef.current
      const displaySize = { width: video.width, height: video.height }

      faceapi.matchDimensions(canvas, displaySize)

      // Detect face
      const detections = await faceapi
        .detectAllFaces(video, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()

      if (detections.length === 0) {
        throw new Error('No face detected. Please ensure your face is clearly visible.')
      }

      if (detections.length > 1) {
        throw new Error('Multiple faces detected. Please ensure only one person is in frame.')
      }

      const detection = detections[0]
      const landmarks = detection.landmarks

      // Draw landmarks for visual feedback
      const context = canvas.getContext('2d')
      if (context) {
        context.clearRect(0, 0, canvas.width, canvas.height)
        faceapi.draw.drawFaceLandmarks(canvas, detection)
      }

      // Calculate face measurements
      const jawPoints = landmarks.getJawOutline()
      const foreheadPoints = landmarks.getForeheadPoints?.(detection) || []
      
      if (jawPoints.length < 3 || foreheadPoints.length < 2) {
        throw new Error('Could not detect facial features clearly')
      }

      // Calculate face width (jawline width)
      const leftJaw = jawPoints[0]
      const rightJaw = jawPoints[jawPoints.length - 1]
      const faceWidth = Math.abs(rightJaw.x - leftJaw.x)

      // Calculate face length (forehead to chin)
      const foreheadCenter = foreheadPoints.length > 0 
        ? foreheadPoints[Math.floor(foreheadPoints.length / 2)]
        : landmarks.positions[27] // Fallback to nose bridge
      const chin = jawPoints[Math.floor(jawPoints.length / 2)]
      const faceLength = Math.abs(chin.y - foreheadCenter.y)

      // Calculate ratio
      const ratio = faceLength / faceWidth

      // Determine face shape based on ratios
      let faceShape = 'OVAL'
      let confidence = 0.7

      if (ratio >= 1.6 && ratio <= 1.9) {
        faceShape = 'DIAMOND'
        confidence = 0.8
      } else if (ratio >= 1.3 && ratio <= 1.6) {
        // Check for heart shape (wide forehead, pointed chin)
        const foreheadWidth = Math.abs(foreheadPoints[foreheadPoints.length - 1].x - foreheadPoints[0].x)
        const isHeartShape = foreheadWidth > faceWidth * 0.9
        faceShape = isHeartShape ? 'HEART' : 'OVAL'
        confidence = isHeartShape ? 0.75 : 0.85
      } else if (ratio >= 1.0 && ratio <= 1.3) {
        // Check for square vs round
        const jawAngles = Math.abs(
          Math.atan2(jawPoints[3].y - jawPoints[0].y, jawPoints[3].x - jawPoints[0].x) -
          Math.atan2(jawPoints[jawPoints.length - 4].y - jawPoints[jawPoints.length - 1].y, 
                     jawPoints[jawPoints.length - 4].x - jawPoints[jawPoints.length - 1].x)
        )
        faceShape = jawAngles < 0.5 ? 'SQUARE' : 'ROUND'
        confidence = 0.8
      }

      // Generate recommendations based on face shape
      const recommendations = getRecommendations(faceShape)

      setResult({
        faceShape,
        confidence,
        recommendations,
        measurements: {
          faceWidth: Math.round(faceWidth),
          faceLength: Math.round(faceLength),
          ratio: Math.round(ratio * 100) / 100,
        },
      })

    } catch (error) {
      console.error('Face analysis error:', error)
      toast.error(error instanceof Error ? error.message : 'Analysis failed. Please try again.')
      setResult(null)
    } finally {
      setIsProcessing(false)
      setIsAnalyzing(false)
    }
  }, [modelsLoaded])

  const getRecommendations = (faceShape: string): string[] => {
    const recommendations: Record<string, string[]> = {
      OVAL: [
        'Most hairstyles suit oval faces',
        'Consider layered cuts for volume',
        'Side-swept bangs complement your shape',
      ],
      ROUND: [
        'Angular cuts create definition',
        'Long layers elongate the face',
        'Side parts add asymmetry',
      ],
      SQUARE: [
        'Soft layers soften jawline',
        'Curly styles add roundness',
        'Long bangs balance forehead',
      ],
      HEART: [
        'Chin-length bobs work well',
        'Side-swept styles balance forehead',
        'Avoid volume at temples',
      ],
      DIAMOND: [
        'Bangs minimize forehead width',
        'Layers at cheekbones soften',
        'Avoid width at cheekbones',
      ],
    }

    return recommendations[faceShape] || ['Try various styles to find your perfect look']
  }

  const resetAnalysis = () => {
    setResult(null)
    setIsAnalyzing(false)
    const canvas = canvasRef.current
    const context = canvas?.getContext('2d')
    if (context && canvas) {
      context.clearRect(0, 0, canvas.width, canvas.height)
    }
  }

  return (
    <div className="glass rounded-2xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-instrument-serif text-2xl italic mb-2 text-[#1A1A1A]">
            AI Face <span className="text-[#D4AF37]">Analysis</span>
          </h3>
          <p className="text-[#1A1A1A]/70">
            Get personalized service recommendations based on your face shape
          </p>
        </div>
        <div className="p-3 bg-[#D4AF37]/10 rounded-xl">
          <Sparkles className="w-6 h-6 text-[#D4AF37]" />
        </div>
      </div>

      {/* Privacy Notice */}
      <div className="mb-6 p-4 bg-[#F0EEE9]/50 rounded-lg">
        <p className="text-sm text-[#1A1A1A]/70">
          <strong className="text-[#1A1A1A]">Privacy First:</strong> All analysis happens in your browser.
          No images are stored or sent to our servers. Processing is 100% client-side.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Camera Feed */}
        <div className="space-y-4">
          <div className="relative aspect-video rounded-xl overflow-hidden bg-[#1A1A1A]/5">
            <video
              ref={videoRef}
              autoPlay
              muted
              playsInline
              className="w-full h-full object-cover"
            />
            <canvas
              ref={canvasRef}
              className="absolute inset-0 pointer-events-none"
            />
            
            {!hasCameraAccess && (
              <div className="absolute inset-0 flex items-center justify-center bg-[#1A1A1A]/10">
                <div className="text-center p-6">
                  <Camera className="w-12 h-12 text-[#1A1A1A]/30 mx-auto mb-4" />
                  <p className="text-[#1A1A1A]/70">
                    Camera access required for analysis
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-3">
            <Button
              onClick={analyzeFace}
              disabled={!hasCameraAccess || isProcessing || !modelsLoaded}
              className="flex-1 tracking-widest group"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  {result ? 'Re-analyze' : 'Analyze My Face'}
                  <Sparkles className="ml-2 h-4 w-4 transition-transform group-hover:rotate-12" />
                </>
              )}
            </Button>
            
            {result && (
              <Button
                onClick={resetAnalysis}
                variant="outline"
                className="tracking-widest"
              >
                <X className="mr-2 h-4 w-4" />
                Reset
              </Button>
            )}
          </div>
        </div>

        {/* Results Panel */}
        <div>
          {result ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="p-6 bg-[#F0EEE9]/50 rounded-xl">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-sm tracking-widest uppercase text-[#1A1A1A]/60 mb-1">
                      Face Shape
                    </div>
                    <div className="font-instrument-serif text-3xl italic text-[#D4AF37]">
                      {result.faceShape}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm tracking-widest uppercase text-[#1A1A1A]/60 mb-1">
                      Confidence
                    </div>
                    <div className="text-2xl font-semibold text-[#1A1A1A]">
                      {Math.round(result.confidence * 100)}%
                    </div>
                  </div>
                </div>

                {/* Measurements */}
                <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-white/10">
                  {Object.entries(result.measurements).map(([key, value]) => (
                    <div key={key} className="text-center">
                      <div className="text-sm tracking-widest uppercase text-[#1A1A1A]/60 mb-1">
                        {key.replace(/([A-Z])/g, ' $1').trim()}
                      </div>
                      <div className="text-lg font-semibold text-[#1A1A1A]">
                        {value}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommendations */}
              <div>
                <h4 className="font-instrument-serif text-xl italic mb-4 text-[#1A1A1A]">
                  Personalized Recommendations
                </h4>
                <ul className="space-y-3">
                  {result.recommendations.map((rec, index) => (
                    <motion.li
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-start gap-3"
                    >
                      <Check className="w-5 h-5 text-[#D4AF37] mt-0.5 flex-shrink-0" />
                      <span className="text-[#1A1A1A]/80">{rec}</span>
                    </motion.li>
                  ))}
                </ul>
              </div>

              <Button
                onClick={() => {
                  // Navigate to services with face shape filter
                  window.location.href = `/services?faceShape=${result.faceShape}`
                }}
                className="w-full tracking-widest"
              >
                View Recommended Services
              </Button>
            </motion.div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-6 text-center">
              <div className="w-16 h-16 rounded-full bg-[#D4AF37]/10 flex items-center justify-center mb-4">
                <Sparkles className="w-8 h-8 text-[#D4AF37]" />
              </div>
              <h4 className="font-instrument-serif text-xl italic mb-2 text-[#1A1A1A]">
                Ready for Analysis
              </h4>
              <p className="text-[#1A1A1A]/70 mb-6">
                Position your face in the camera frame and click "Analyze My Face" to get personalized recommendations
              </p>
              <div className="space-y-3 text-sm text-[#1A1A1A]/60">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#D4AF37] rounded-full" />
                  <span>Ensure good lighting</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#D4AF37] rounded-full" />
                  <span>Remove glasses if possible</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#D4AF37] rounded-full" />
                  <span>Keep hair away from face</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}