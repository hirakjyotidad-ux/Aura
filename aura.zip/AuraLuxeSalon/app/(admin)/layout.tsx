'use client'

import { useState, useEffect } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { supabase } from '@/lib/supabase'
import { Loader2, Menu, X } from 'lucide-react'
import { cn } from '@/lib/utils'

const adminMenuItems = [
  { label: 'Dashboard', href: '/admin/dashboard', icon: '📊' },
  { label: 'Bookings', href: '/admin/bookings', icon: '📅' },
  { label: 'Services', href: '/admin/services', icon: '✂️' },
  { label: 'Analytics', href: '/admin/analytics', icon: '📈' },
]

export default function AdminLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const router = useRouter()
  const pathname = usePathname()
  const [isLoading, setIsLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession()
      
      if (error) throw error
      
      if (!session) {
        router.push('/admin/login')
        return
      }

      // Check if user has admin role (you would need to implement this in your auth setup)
      const { data: userData } = await supabase.auth.getUser()
      // Implement your role check logic here
      
      setIsAuthenticated(true)
    } catch (error) {
      console.error('Auth error:', error)
      router.push('/admin/login')
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/admin/login')
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F0EEE9] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#D4AF37] animate-spin" />
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-[#F0EEE9]">
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-2 glass rounded-lg"
        >
          {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Sidebar */}
      <AnimatePresence>
        {(sidebarOpen || window.innerWidth >= 1024) && (
          <motion.aside
            initial={{ x: -280 }}
            animate={{ x: 0 }}
            exit={{ x: -280 }}
            className="fixed inset-y-0 left-0 z-40 w-64 glass border-r border-white/10"
          >
            <div className="flex flex-col h-full">
              {/* Logo */}
              <div className="p-6 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-[#D4AF37] rounded-sm rotate-45" />
                  <div>
                    <div className="font-instrument-serif text-xl italic text-[#1A1A1A]">
                      Aura<span className="not-italic">-Luxe</span>
                    </div>
                    <div className="text-xs tracking-widest uppercase text-[#1A1A1A]/60">
                      Admin Dashboard
                    </div>
                  </div>
                </div>
              </div>

              {/* Menu Items */}
              <nav className="flex-1 p-4">
                <ul className="space-y-1">
                  {adminMenuItems.map((item) => (
                    <li key={item.href}>
                      <a
                        href={item.href}
                        onClick={() => setSidebarOpen(false)}
                        className={cn(
                          'flex items-center gap-3 px-4 py-3 rounded-lg transition-colors',
                          pathname === item.href
                            ? 'bg-[#D4AF37] text-[#1A1A1A]'
                            : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#F0EEE9]/50'
                        )}
                      >
                        <span className="text-xl">{item.icon}</span>
                        <span className="text-sm tracking-widest uppercase">
                          {item.label}
                        </span>
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>

              {/* User & Logout */}
              <div className="p-4 border-t border-white/10">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm tracking-widest uppercase text-[#1A1A1A]/70 hover:text-[#A71F13] hover:bg-[#F0EEE9]/50 rounded-lg transition-colors"
                >
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className={cn(
        'min-h-screen transition-all',
        sidebarOpen ? 'lg:ml-64' : 'lg:ml-64'
      )}>
        <main className="p-4 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}