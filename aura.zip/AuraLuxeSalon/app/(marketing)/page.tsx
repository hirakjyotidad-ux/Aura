import { Hero } from '@/components/features/hero'
import { ServicesGrid } from '@/components/features/services-grid'
import { Gallery } from '@/components/features/gallery'
import { CTASection } from '@/components/features/cta-section'

export default function HomePage() {
  return (
    <div className="pt-16">
      <Hero />
      <ServicesGrid />
      <Gallery />
      <CTASection />
    </div>
  )
}