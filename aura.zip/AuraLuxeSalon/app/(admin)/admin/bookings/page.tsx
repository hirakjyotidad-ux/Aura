'use client'

import { useState, useEffect, useCallback } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Search,
  MoreVertical,
  Calendar,
  User,
  Phone,
  Mail,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Download,
  Filter,
} from 'lucide-react'
import { formatDate, formatTime, formatPrice } from '@/lib/utils'
import { supabase } from '@/lib/supabase'
import { toast } from 'sonner'
import { Booking } from '@/lib/database.types'

type BookingWithService = Booking & {
  services: {
    name: string
    price: number
  } | null
}

export default function BookingsPage() {
  const [bookings, setBookings] = useState<BookingWithService[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [selectedBooking, setSelectedBooking] = useState<BookingWithService | null>(null)
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false)
  const [isCancelling, setIsCancelling] = useState(false)

  const fetchBookings = useCallback(async () => {
    try {
      setLoading(true)
      
      let query = supabase
        .from('bookings')
        .select(`
          *,
          services (
            name,
            price
          )
        `)
        .order('booking_date', { ascending: false })

      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter)
      }

      if (searchQuery) {
        query = query.or(`customer_name.ilike.%${searchQuery}%,customer_email.ilike.%${searchQuery}%`)
      }

      const { data, error } = await query

      if (error) throw error
      setBookings(data || [])
    } catch (error) {
      console.error('Error fetching bookings:', error)
      toast.error('Failed to load bookings')
    } finally {
      setLoading(false)
    }
  }, [searchQuery, statusFilter])

  useEffect(() => {
    fetchBookings()
  }, [fetchBookings])

  const handleCancelBooking = async (bookingId: string) => {
    setIsCancelling(true)
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'cancelled' })
        .eq('id', bookingId)

      if (error) throw error

      toast.success('Booking cancelled successfully')
      setCancelDialogOpen(false)
      fetchBookings()
    } catch (error) {
      console.error('Error cancelling booking:', error)
      toast.error('Failed to cancel booking')
    } finally {
      setIsCancelling(false)
    }
  }

  const exportToCSV = () => {
    const headers = ['Date', 'Time', 'Customer', 'Service', 'Status', 'Phone', 'Email']
    const csvData = bookings.map(booking => [
      formatDate(booking.booking_date),
      formatTime(booking.start_time),
      booking.customer_name,
      booking.services?.name || 'N/A',
      booking.status,
      booking.customer_phone || 'N/A',
      booking.customer_email,
    ])

    const csvContent = [
      headers.join(','),
      ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `bookings-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      confirmed: { className: 'bg-green-500/10 text-green-700', icon: CheckCircle },
      pending: { className: 'bg-yellow-500/10 text-yellow-700', icon: Clock },
      cancelled: { className: 'bg-red-500/10 text-red-700', icon: XCircle },
      completed: { className: 'bg-blue-500/10 text-blue-700', icon: CheckCircle },
      'no-show': { className: 'bg-gray-500/10 text-gray-700', icon: AlertCircle },
    }

    const variant = variants[status as keyof typeof variants] || variants.pending
    const Icon = variant.icon

    return (
      <Badge className={variant.className}>
        <Icon className="w-3 h-3 mr-1" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-instrument-serif text-3xl md:text-4xl italic mb-2 text-[#1A1A1A]">
            Booking <span className="text-[#D4AF37]">Management</span>
          </h1>
          <p className="text-[#1A1A1A]/70">
            Manage appointments, view customer details, and handle booking operations
          </p>
        </div>
        <Button
          onClick={exportToCSV}
          variant="outline"
          className="tracking-widest"
        >
          <Download className="mr-2 h-4 w-4" />
          Export CSV
        </Button>
      </div>

      {/* Filters */}
      <div className="glass rounded-xl p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#1A1A1A]/40 w-4 h-4" />
            <Input
              placeholder="Search by name or email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="tracking-widest">
                  <Filter className="mr-2 h-4 w-4" />
                  Status: {statusFilter === 'all' ? 'All' : statusFilter}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setStatusFilter('all')}>
                  All Statuses
                </DropdownMenuItem>
                {['confirmed', 'pending', 'cancelled', 'completed', 'no-show'].map((status) => (
                  <DropdownMenuItem
                    key={status}
                    onClick={() => setStatusFilter(status)}
                  >
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Bookings Table */}
      <div className="glass rounded-xl overflow-hidden">
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="w-8 h-8 text-[#D4AF37] animate-spin" />
          </div>
        ) : bookings.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-[#1A1A1A]/70">No bookings found</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bookings.map((booking) => (
                  <TableRow key={booking.id} className="group">
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-[#1A1A1A]/40" />
                          <span className="font-medium">
                            {formatDate(booking.booking_date)}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-[#1A1A1A]/60">
                          <Clock className="w-4 h-4" />
                          {formatTime(booking.start_time)} - {formatTime(booking.end_time)}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-[#1A1A1A]/40" />
                          <span className="font-medium">{booking.customer_name}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-[#1A1A1A]/60">
                          <Mail className="w-4 h-4" />
                          {booking.customer_email}
                        </div>
                        {booking.customer_phone && (
                          <div className="flex items-center gap-2 text-sm text-[#1A1A1A]/60">
                            <Phone className="w-4 h-4" />
                            {booking.customer_phone}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {booking.services?.name || 'N/A'}
                        </div>
                        <div className="text-sm text-[#1A1A1A]/60">
                          {booking.services?.price ? formatPrice(booking.services.price) : 'N/A'}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(booking.status)}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => setSelectedBooking(booking)}
                          >
                            View Details
                          </DropdownMenuItem>
                          {booking.status === 'confirmed' && (
                            <DropdownMenuItem
                              onClick={() => {
                                setSelectedBooking(booking)
                                setCancelDialogOpen(true)
                              }}
                              className="text-[#A71F13]"
                            >
                              Cancel Booking
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem
                            onClick={() => {
                              // Mark as completed
                              // Implement this functionality
                            }}
                          >
                            Mark as Completed
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      {/* Cancel Booking Dialog */}
      <Dialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel Booking</DialogTitle>
            <DialogDescription>
              Are you sure you want to cancel this booking? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="space-y-4">
              <div className="p-4 bg-[#F0EEE9]/50 rounded-lg">
                <div className="font-medium mb-2">Booking Details</div>
                <div className="text-sm text-[#1A1A1A]/70 space-y-1">
                  <div>Customer: {selectedBooking.customer_name}</div>
                  <div>Service: {selectedBooking.services?.name}</div>
                  <div>Date: {formatDate(selectedBooking.booking_date)}</div>
                  <div>Time: {formatTime(selectedBooking.start_time)}</div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setCancelDialogOpen(false)}
              disabled={isCancelling}
            >
              Keep Booking
            </Button>
            <Button
              variant="destructive"
              onClick={() => selectedBooking && handleCancelBooking(selectedBooking.id)}
              disabled={isCancelling}
            >
              {isCancelling ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Cancelling...
                </>
              ) : (
                'Cancel Booking'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}