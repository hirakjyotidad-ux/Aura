"use client"

import { Toaster as SonnerToaster } from "sonner"
import { useTheme } from "next-themes"

export function Toaster() {
  const { theme } = useTheme()

  return (
    <SonnerToaster
      theme={theme as "light" | "dark" | "system"}
      className="toaster group"
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-[#F0EEE9] group-[.toaster]:text-[#1A1A1A] group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-[#1A1A1A]/70",
          actionButton:
            "group-[.toast]:bg-[#D4AF37] group-[.toast]:text-[#1A1A1A]",
          cancelButton:
            "group-[.toast]:bg-[#F0EEE9]/50 group-[.toast]:text-[#1A1A1A]",
        },
      }}
      position="bottom-right"
      duration={4000}
      expand={false}
      richColors
      closeButton
    />
  )
}