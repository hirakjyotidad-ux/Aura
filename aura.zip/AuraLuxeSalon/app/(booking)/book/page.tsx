'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { useBooking } from '@/components/providers/booking-provider'
import { ArrowRight, Clock, Sparkles } from 'lucide-react'
import { formatPrice } from '@/lib/utils'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'

interface Service {
  id: string
  name: string
  description: string | null
  price: number
  duration_minutes: number
  category: string
}

export default function ServiceSelectionPage() {
  const router = useRouter()
  const { setBookingData, bookingData } = useBooking()
  const [services, setServices] = useState<Service[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedService, setSelectedService] = useState<string | null>(bookingData.serviceId)

  useEffect(() => {
    async function fetchServices() {
      try {
        const { data, error } = await supabase
          .from('services')
          .select('*')
          .eq('is_active', true)
          .order('category')

        if (error) throw error
        setServices(data || [])
      } catch (error) {
        console.error('Error fetching services:', error)
        toast.error('Failed to load services')
      } finally {
        setLoading(false)
      }
    }

    fetchServices()
  }, [])

  const handleServiceSelect = (serviceId: string) => {
    setSelectedService(serviceId)
  }

  const handleContinue = () => {
    if (!selectedService) {
      toast.error('Please select a service')
      return
    }

    const service = services.find(s => s.id === selectedService)
    if (!service) return

    setBookingData({
      serviceId: selectedService,
      serviceName: service.name,
      servicePrice: service.price,
      serviceDuration: service.duration_minutes,
    })

    router.push('/book/date')
  }

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div
              key={i}
              className="h-64 glass rounded-2xl animate-pulse"
            />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="font-instrument-serif text-4xl md:text-5xl italic mb-4 text-[#1A1A1A]">
          Choose Your <span className="text-[#D4AF37]">Experience</span>
        </h1>
        <p className="text-lg text-[#1A1A1A]/70">
          Select a service to begin your booking journey
        </p>
      </motion.div>

      {/* AI Recommendation Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass rounded-2xl p-6 mb-8"
      >
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-[#D4AF37]/10 rounded-xl">
              <Sparkles className="w-6 h-6 text-[#D4AF37]" />
            </div>
            <div>
              <h3 className="font-instrument-serif text-xl italic mb-1 text-[#1A1A1A]">
                Not sure what suits you best?
              </h3>
              <p className="text-[#1A1A1A]/70">
                Try our AI Face Analysis for personalized recommendations
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            className="tracking-widest"
            onClick={() => router.push('/book/ai-analysis')}
          >
            Try AI Analysis
          </Button>
        </div>
      </motion.div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((service) => (
          <motion.div
            key={service.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ y: -4 }}
            className={cn(
              'glass rounded-2xl p-6 cursor-pointer transition-all',
              selectedService === service.id
                ? 'ring-2 ring-[#D4AF37] ring-offset-2 ring-offset-[#F0EEE9]'
                : 'hover:shadow-lg'
            )}
            onClick={() => handleServiceSelect(service.id)}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <span className="text-xs tracking-widest uppercase text-[#1A1A1A]/60">
                  {service.category}
                </span>
                <h3 className="font-instrument-serif text-2xl italic mt-2 mb-3 text-[#1A1A1A]">
                  {service.name}
                </h3>
              </div>
              <div className="text-right">
                <div className="text-lg font-semibold text-[#D4AF37]">
                  {formatPrice(service.price)}
                </div>
                <div className="flex items-center gap-1 text-sm text-[#1A1A1A]/60 mt-1">
                  <Clock className="w-4 h-4" />
                  {service.duration_minutes} min
                </div>
              </div>
            </div>

            <p className="text-[#1A1A1A]/70 mb-6 line-clamp-2">
              {service.description}
            </p>

            <div className="flex items-center justify-between">
              <span className="text-xs tracking-widest uppercase text-[#D4AF37]">
                {selectedService === service.id ? 'Selected' : 'Select'}
              </span>
              <div className={cn(
                'w-6 h-6 rounded-full border-2 transition-colors',
                selectedService === service.id
                  ? 'bg-[#D4AF37] border-[#D4AF37]'
                  : 'border-[#1A1A1A]/20'
              )}>
                {selectedService === service.id && (
                  <div className="w-full h-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-[#1A1A1A] rounded-full" />
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Continue Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mt-12 flex justify-end"
      >
        <Button
          onClick={handleContinue}
          disabled={!selectedService}
          size="lg"
          className="tracking-widest group"
        >
          Continue to Date Selection
          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Button>
      </motion.div>
    </div>
  )
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ')
}