-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Services table
CREATE TABLE services (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    duration_minutes INTEGER NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (category IN ('hair', 'skin', 'nails', 'makeup')),
    image_url TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bookings table with concurrency-safe slot limiting
CREATE TABLE bookings (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    service_id UUID REFERENCES services(id) ON DELETE RESTRICT,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(20),
    booking_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status VARCHAR(20) DEFAULT 'confirmed' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled', 'no-show')),
    notes TEXT,
    face_shape VARCHAR(50),
    recommended_service_id UUID REFERENCES services(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_bookings_date ON bookings(booking_date);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_bookings_user ON bookings(user_id);
CREATE UNIQUE INDEX idx_booking_slot_lookup ON bookings(booking_date, start_time, service_id, status) WHERE status IN ('confirmed', 'pending');

-- Function to check slot availability
CREATE OR REPLACE FUNCTION check_booking_capacity()
RETURNS TRIGGER AS $$
DECLARE
    current_count INTEGER;
    max_capacity INTEGER := 2; -- From environment variable
BEGIN
    -- Count confirmed/pending bookings for this slot
    SELECT COUNT(*)
    INTO current_count
    FROM bookings
    WHERE booking_date = NEW.booking_date
        AND start_time = NEW.start_time
        AND status IN ('confirmed', 'pending');
    
    -- If at capacity, reject the booking
    IF current_count >= max_capacity THEN
        RAISE EXCEPTION 'Booking slot at maximum capacity (%)', max_capacity
        USING ERRCODE = 'check_violation';
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to enforce capacity before insert/update
CREATE TRIGGER enforce_booking_capacity
    BEFORE INSERT OR UPDATE OF booking_date, start_time, status
    ON bookings
    FOR EACH ROW
    EXECUTE FUNCTION check_booking_capacity();

-- RLS Policies
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Services: Public read, admin write
CREATE POLICY "Services are viewable by everyone" ON services
    FOR SELECT USING (true);

CREATE POLICY "Services can be managed by admin" ON services
    FOR ALL USING (auth.jwt() ->> 'role' = 'admin');

-- Bookings: Users can insert their own, admins can manage all
CREATE POLICY "Users can create bookings" ON bookings
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view their own bookings" ON bookings
    FOR SELECT USING (auth.jwt() ->> 'sub' = user_id::text OR auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Admins can manage all bookings" ON bookings
    FOR ALL USING (auth.jwt() ->> 'role' = 'admin');

-- Function to get available slots
CREATE OR REPLACE FUNCTION get_available_slots(
    p_date DATE,
    p_service_id UUID
)
RETURNS TABLE (
    start_time TIME,
    end_time TIME,
    available_count INTEGER
) AS $$
BEGIN
    RETURN QUERY
    WITH service AS (
        SELECT duration_minutes FROM services WHERE id = p_service_id
    ),
    all_slots AS (
        SELECT 
            generate_series(
                '09:00'::TIME,
                '17:00'::TIME,
                '30 minutes'::INTERVAL
            ) AS slot_start,
            generate_series(
                '09:30'::TIME,
                '17:30'::TIME,
                '30 minutes'::INTERVAL
            ) AS slot_end
    ),
    bookings_for_date AS (
        SELECT start_time, COUNT(*) as booked_count
        FROM bookings
        WHERE booking_date = p_date
            AND status IN ('confirmed', 'pending')
        GROUP BY start_time
    )
    SELECT 
        s.slot_start::TIME as start_time,
        s.slot_end::TIME as end_time,
        GREATEST(2 - COALESCE(b.booked_count, 0), 0) as available_count
    FROM all_slots s
    LEFT JOIN bookings_for_date b ON s.slot_start = b.start_time
    WHERE s.slot_start >= '09:00'::TIME
        AND s.slot_end <= '17:30'::TIME
    ORDER BY s.slot_start;
END;
$$ LANGUAGE plpgsql;

-- Updated_at trigger for both tables
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_services_updated_at
    BEFORE UPDATE ON services
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at
    BEFORE UPDATE ON bookings
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();