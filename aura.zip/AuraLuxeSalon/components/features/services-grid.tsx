'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { Clock, Sparkles, Heart, Palette } from 'lucide-react'
import { formatPrice } from '@/lib/utils'
import { supabase } from '@/lib/supabase'

interface Service {
  id: string
  name: string
  description: string | null
  price: number
  duration_minutes: number
  category: 'hair' | 'skin' | 'nails' | 'makeup'
  image_url: string | null
}

const categoryIcons = {
  hair: Sparkles,
  skin: Heart,
  nails: Palette,
  makeup: Sparkles,
}

export function ServicesGrid() {
  const [services, setServices] = useState<Service[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchServices() {
      try {
        const { data, error } = await supabase
          .from('services')
          .select('*')
          .eq('is_active', true)
          .order('price')

        if (error) throw error
        setServices(data || [])
      } catch (error) {
        console.error('Error fetching services:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchServices()
  }, [])

  if (loading) {
    return (
      <section className="py-20 bg-[#F0EEE9]/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="h-64 bg-[#F0EEE9]/70 animate-pulse rounded-2xl"
              />
            ))}
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-20 bg-[#F0EEE9]/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-instrument-serif text-4xl md:text-5xl italic mb-4 text-[#1A1A1A]">
            Signature <span className="text-[#D4AF37]">Services</span>
          </h2>
          <p className="text-lg text-[#1A1A1A]/70 max-w-2xl mx-auto">
            Each service is crafted to bring out your natural beauty and confidence
          </p>
        </motion.div>

        {/* Bento Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = categoryIcons[service.category]
            const isFeatured = index === 0

            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={cn(
                  'glass rounded-2xl p-6 flex flex-col',
                  isFeatured && 'md:col-span-2 md:row-span-2'
                )}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-[#D4AF37]/10 rounded-lg">
                      <Icon className="w-5 h-5 text-[#D4AF37]" />
                    </div>
                    <span className="text-xs tracking-widest uppercase text-[#1A1A1A]/60">
                      {service.category}
                    </span>
                  </div>
                  {service.image_url && (
                    <div className="w-16 h-16 rounded-lg overflow-hidden">
                      {/* In production, use next/image */}
                      <img
                        src={service.image_url}
                        alt={service.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                </div>

                <h3 className="font-instrument-serif text-2xl italic mb-3 text-[#1A1A1A]">
                  {service.name}
                </h3>

                <p className="text-[#1A1A1A]/70 mb-4 flex-grow">
                  {service.description}
                </p>

                <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/10">
                  <div className="flex items-center gap-4">
                    <div className="text-lg font-semibold text-[#D4AF37]">
                      {formatPrice(service.price)}
                    </div>
                    <div className="flex items-center gap-1 text-sm text-[#1A1A1A]/60">
                      <Clock className="w-4 h-4" />
                      {service.duration_minutes} min
                    </div>
                  </div>
                  <Button
                    asChild
                    variant="outline"
                    size="sm"
                    className="tracking-widest"
                  >
                    <Link href={`/book?service=${service.id}`}>
                      Book
                    </Link>
                  </Button>
                </div>
              </motion.div>
            )
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Button
            asChild
            variant="outline"
            size="lg"
            className="tracking-widest"
          >
            <Link href="/services">
              View All Services
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  )
}

function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ')
}